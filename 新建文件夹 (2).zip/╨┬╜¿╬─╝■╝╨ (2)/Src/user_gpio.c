/**
  ******************************************************************************
  * @file     gpio.c      
  * @author   Jiangwholesome  
  * @version  V1.0  
  * @date     2019/7/31   
  * @brief        
  *                   
  *                    
  *                    
  ******************************************************************************
*/
/* Includes ------------------------------------------------------------------*/
/*某个文件的头文件包含在本文件内定义的函数定义
等，如果不是头文件内需要用到其他的头文件，直接
把头文件放在外边
*/
#include "main.h"
#include "user_gpio.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
/**
* @brief   所有项目都需要配置相应的IO口，该函数为公用接口函数
  * 
  * @note   
  *             
  * @param  None 
  *                
  * @retval None
  */


GPIO_InitTypeDef   GPIO_InitStructure;//定义不能放在中间
 
void User_GPIO_Init(GPIO_TypeDef* GPIOX, uint16_t GPIO_PIN_X, int flag)
{
	
    /*灯的初始化*/
	if(flag == 0)
	{
		GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStructure.Pull = GPIO_NOPULL;
		GPIO_InitStructure.Pin  = GPIO_PIN_X;  
		HAL_GPIO_Init(GPIOX,&GPIO_InitStructure);
	}
	else
	{
		GPIO_InitStructure.Mode = GPIO_MODE_INPUT;
		GPIO_InitStructure.Pull = GPIO_PULLUP;
		GPIO_InitStructure.Pin  = GPIO_PIN_X;  
		HAL_GPIO_Init(GPIOX,&GPIO_InitStructure);
	}
	//HAL_GPIO_WritePin(GPIOA,GPIO_PIN_3,GPIO_PIN_SET);
	
//	GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
//    GPIO_InitStructure.Pull = GPIO_NOPULL;
//    GPIO_InitStructure.Pin  = GPIO_PIN_0;  
//    HAL_GPIO_Init(GPIOB,&GPIO_InitStructure);
//	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_0,GPIO_PIN_SET);
}

/*****************************END OF FILE***********************/
