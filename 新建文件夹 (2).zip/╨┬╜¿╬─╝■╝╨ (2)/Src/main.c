/**
  ******************************************************************************
  * @file     mian.c      
  * @author   Jiangwholesome  
  * @version  V1.0  
  * @date     2019/7/31   
  * @brief        
  *                   
  *                    
  *          
  * @file     mian.c      
  * @author   wuqichao  
  * @version  V2.0  
  * @date     2019/08/05  
  * @brief    1.添加了IO部分的检测和控制，包含了传感器的检测和LED灯的控制；
  *			  2.修改了原先协议解析的代码；
  *           3.添加了解析协议后对LED灯的控制。
  ******************************************************************************
*/

/* Includes ------------------------------------------------------------------
*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "main.h"
#include "user_crc.h"
#include "cJSON.h"
#include "cJSON_Utils.h"
#include "user_gpio.h"
#include "user_uart.h"
#include "interrupt.h"
#include "user_timer.h"

#define ESP_RX_MAX_LEN 600
typedef struct InitMember
{
	char *pSSID;
	char *pPassWord;
	char *ip;
}InitMember;
//InitMember  test = {"824","1234qwer","10.10.8.177"};
//InitMember  test = {"Jimi-8","1234qwer","10.10.8.177"};
InitMember  test = {"Jimi-4","1234qwer","10.10.11.129"};
typedef struct DeviceInfo
{
	char ip[20];
	char mac[20];
}DeviceInfo;
DeviceInfo deviceinfo ={0,0};

loginstatus DeviceLoginStatus = LOGOUT;



protocal_send_switch ProtocalSendSwitch = {SWITCH_OFF,SWITCH_OFF};
/* Private function prototypes -----------------------------------------------*/
static void User_IWDG_Init(void);

static void User_Feed_IWDG(void);

static void User_Check_MCU_Reset_Reason(void);

static void User_Main_Init(void);

static void GPIO_CLK_ENABLE(void);

static void User_Led_Control(int IED_ID, uint8_t STATE, uint8_t MSG_ID);

uint8_t ParseScanCodeJson(const char* pszJsonText);

static void ParseJsonExample(const char* data);

static void User_Sensor_Check(void);

static void User_Alarm(uint8_t _switch, uint8_t msg_id);
void DeviceLogin(loginstatus * DeviceLoginStatus);/*不要用值传递*/
bool esp8266_send_cmd(char *cmd,char *reply,uint32_t waittime);
bool esp8266_mode(uint8_t enumMode);
bool esp8266_Rst(void);
bool esp8266_Join_AP(char *pSSID,char *pPassWord);
bool esp8266_Get_Ip(void);
bool esp8266_link_Server(char *ip);
bool esp8266_UnvarnishSend(void);
bool esp8266_DateTC(void);

char * CopyContentBetweenTwoSymbols(char *dest, char *src,char *symbol_one,char *symbol_two);

void *User_Memcpy(void *desc,const void * src,size_t size);
//bool esp8266_UnvarnishSend(void);
//bool esp8266_send_cmd(char *cmd,char *reply,uint32_t waittime);
//int ESP8266_SendCmd(char* cmd, char* reply, int wait);

//int ESP8266_SendCmd(char* cmd, char* reply, int wait);

void User_Send_Data(void);

/* Private variables ---------------------------------------------------------*/
//char* pszJsonText = "{\"result\":{\"ID\":1,\"name\":\"aa\",\"datetime\":\"2016-04-25 16:38:54\",\"status\":1},\"code\":10000,\"message\":\"ok\",\"sign\":901498365}";
/*串口会传递过来的包含转移字符码{\"love\":[\"LOL\",\"Go shopping\",\"jogging\"]} */
char* data = "{\"cmd\":[\"led\",\"2\",\"false\"]}";
char* JsonText = "{\"id\":1,\"direction\":0,\"type\":\"light\",\"body\":{\"no\":37,\"state\":\"true\"},\"crc\":44}#";
char *data1 ="{\"id\":2,\"direction\":1,\"type\":\"login\",\"body\":{\"result\":0},\"crc\":49}";

char sensor_state_new[40];
char sensor_state[40];
uint8_t cnt = 0;
uint8_t cnt_tmp = 0;

extern  char buffer[SIZE_OF_FULL_BUFFER] ;
   
   
gpio led[40] = {
		{GPIOA, GPIO_PIN_5},{GPIOA, GPIO_PIN_6},{GPIOA, GPIO_PIN_7},{GPIOB, GPIO_PIN_6},{GPIOC, GPIO_PIN_7},
		{GPIOA, GPIO_PIN_9},{GPIOA, GPIO_PIN_8},{GPIOB, GPIO_PIN_10},{GPIOB, GPIO_PIN_4},{GPIOB, GPIO_PIN_5},
		{GPIOB, GPIO_PIN_3},{GPIOA, GPIO_PIN_10},{GPIOA, GPIO_PIN_2},{GPIOA, GPIO_PIN_3},{GPIOA, GPIO_PIN_12},
		{GPIOA, GPIO_PIN_11},{GPIOB, GPIO_PIN_12},{GPIOB, GPIO_PIN_11},{GPIOB, GPIO_PIN_2},{GPIOB, GPIO_PIN_1},
		{GPIOB, GPIO_PIN_15},{GPIOB, GPIO_PIN_14},{GPIOB, GPIO_PIN_13},{GPIOC, GPIO_PIN_4},{GPIOF, GPIO_PIN_5},
		{GPIOF, GPIO_PIN_4},{GPIOE, GPIO_PIN_8},{GPIOF, GPIO_PIN_10},{GPIOE, GPIO_PIN_7},{GPIOD, GPIO_PIN_14},
		{GPIOD, GPIO_PIN_15},{GPIOF, GPIO_PIN_14},{GPIOE, GPIO_PIN_9},{GPIOE, GPIO_PIN_11},{GPIOF, GPIO_PIN_3},
		{GPIOF, GPIO_PIN_15},{GPIOF, GPIO_PIN_11},{GPIOE, GPIO_PIN_0},{GPIOG, GPIO_PIN_8},{GPIOG, GPIO_PIN_5},
};

gpio sensor[40] = {
		{GPIOF, GPIO_PIN_6},{GPIOF, GPIO_PIN_7},{GPIOA, GPIO_PIN_13},{GPIOA, GPIO_PIN_14},{GPIOA, GPIO_PIN_15},
		{GPIOA, GPIO_PIN_0},{GPIOA, GPIO_PIN_1},{GPIOA, GPIO_PIN_4},{GPIOB, GPIO_PIN_0},{GPIOC, GPIO_PIN_1},
		{GPIOC, GPIO_PIN_0},{GPIOD, GPIO_PIN_4},{GPIOD, GPIO_PIN_5},{GPIOD, GPIO_PIN_6},{GPIOD, GPIO_PIN_7},
		{GPIOE, GPIO_PIN_3},{GPIOF, GPIO_PIN_1},{GPIOF, GPIO_PIN_0},{GPIOD, GPIO_PIN_1},{GPIOD, GPIO_PIN_0},
		{GPIOG, GPIO_PIN_0},{GPIOE, GPIO_PIN_1},{GPIOG, GPIO_PIN_9},{GPIOG, GPIO_PIN_12},{GPIOB, GPIO_PIN_7},
		{GPIOD, GPIO_PIN_3},{GPIOG, GPIO_PIN_2},{GPIOG, GPIO_PIN_3},{GPIOE, GPIO_PIN_2},{GPIOE, GPIO_PIN_4},
		{GPIOE, GPIO_PIN_5},{GPIOF, GPIO_PIN_2},{GPIOF, GPIO_PIN_8},{GPIOF, GPIO_PIN_9},{GPIOG, GPIO_PIN_1},
		{GPIOE, GPIO_PIN_6},{GPIOG, GPIO_PIN_15},{GPIOG, GPIO_PIN_10},{GPIOG, GPIO_PIN_13},{GPIOG, GPIO_PIN_11},
};


 typedef struct
 {
    uint32_t LED_ID;
    char *STATE;
 }SCAN_CODE_LIST_MEM_TypeDef;

int main(void)
{
	User_Main_Init();
	
	/*JSON解析示例*/
	#if 0
	ParseJsonExample(data);
	ParseScanCodeJson(JsonText);
	//char *str = "+CIFSR:STAIP,\"10.10.8.185\"\r\n+CIFSR:STAMAC,\"ec:fa:bc:51:c5:25\"\r\nOK",*str1[100]="abc";
	//printf("where %s\n",strstr(str,"\""));
	//User_Memcpy(str1, str, 10);
	//printf("where %s\n",str1);
	cJSON   *root;
	root = cJSON_Parse(data1);
	if(root)
	{
		printf("id %d\n",cJSON_GetObjectItem(root, "id")->valueint);
		printf("body %s\n",cJSON_Print(cJSON_GetObjectItem(root, "body")));
	}
	#endif
    while(1)
    {
		/*登录*/
		DeviceLogin(&DeviceLoginStatus);
		
        /*串口数据解析回复*/
        User_UART_Data_Analyze_Respond();
		
		if(DeviceLoginStatus == LOGIN)
		{
			/*投料辅助器光纤传感器检测*/
			User_Sensor_Check();
		}
		User_Send_Data();
		//User_Feed_IWDG();
    }
}
void User_Send_Data(void)
{
	if(ProtocalSendSwitch.login_info_switch == SWITCH_ON)
	{
		static uint8_t counter = 0;
		if(User_Timer_Start_Check(TIMER_ID_SEND_LOGIN_INFO) == TIMER_STOP)
		{
			counter = 0;
			User_Timer_Start(TIMER_ID_SEND_LOGIN_INFO,0);
		}
		if(User_Timer_Start_Expire_Check(TIMER_ID_SEND_LOGIN_INFO))
		{
			User_Timer_Start(TIMER_ID_SEND_LOGIN_INFO,5000);
			counter++;
			//printf("here %d\n",counter);
			if(counter < 5)
			{
				char BufferWithoutCrc[1024] = {0};
				snprintf(BufferWithoutCrc,1000,"{\"id\":2,\"direction\":0,\"type\":\"login\",\"body\":{\"mac\":\"%s\"}}",deviceinfo.mac);
				//printf("BufferWithoutCrc %s\n",BufferWithoutCrc);
				uint32_t crc = CheckCrc(BufferWithoutCrc,strlen(BufferWithoutCrc));
				snprintf(BufferWithoutCrc,1000,"{\"id\":2,\"direction\":0,\"type\":\"login\",\"body\":{\"mac\":\"%s\"},\"crc\":%d}#",deviceinfo.mac,crc);
				printf("%s\n",BufferWithoutCrc);
			}
			else/*5次没有回应，重新联网，后面加入必要提示，如指示灯*/
			{
				ProtocalSendSwitch.login_info_switch = SWITCH_OFF;/*停止发送*/
				DeviceLoginStatus = LOGOUT;
				User_Timer_Stop(TIMER_ID_SEND_LOGIN_INFO);
			}
		}
	}
	else
	{
		if(User_Timer_Start_Check(TIMER_ID_SEND_LOGIN_INFO) == TIMER_START)
		{
			User_Timer_Stop(TIMER_ID_SEND_LOGIN_INFO);
		}
	}
	
	if(ProtocalSendSwitch.sensor_scan_result_switch == SWITCH_ON)
	{
		static uint8_t counter = 0;
		if(User_Timer_Start_Check(TIMER_ID_SEND_SENSOR_SCAN_RESULT) == TIMER_STOP)
		{
			counter = 0;
			User_Timer_Start(TIMER_ID_SEND_SENSOR_SCAN_RESULT,0);
		}
		if(User_Timer_Start_Expire_Check(TIMER_ID_SEND_SENSOR_SCAN_RESULT))
		{
			User_Timer_Start(TIMER_ID_SEND_SENSOR_SCAN_RESULT,5000);
			counter++;
			//printf("here %d\n",counter);
			if(counter < 5)
			{
				char BufferWithoutCrc[1024] = {0};
				snprintf(BufferWithoutCrc,1000,"{\"id\":11,\"direction\":0,\"type\":\"input\",\"body\":{\"no\":%d}}",cnt_tmp);
				//printf("BufferWithoutCrc %s\n",BufferWithoutCrc);
				uint32_t crc = CheckCrc(BufferWithoutCrc,strlen(BufferWithoutCrc));
				snprintf(BufferWithoutCrc,1000,"{\"id\":11,\"direction\":0,\"type\":\"input\",\"body\":{\"no\":%d},\"crc\":%d}#",cnt_tmp,crc);
				printf("%s\n",BufferWithoutCrc);
			}
			else/*5次没有回应，重新联网，后面加入必要提示，如指示灯*/
			{
				ProtocalSendSwitch.sensor_scan_result_switch = SWITCH_OFF;/*停止发送*/
			}
		}
	}
	else
	{
		if(User_Timer_Start_Check(TIMER_ID_SEND_SENSOR_SCAN_RESULT) == TIMER_START)
		{
			User_Timer_Stop(TIMER_ID_SEND_SENSOR_SCAN_RESULT);
		}
	}
}
void *User_Memcpy(void *desc,const void * src,size_t size)
{ 
	if((desc == NULL) && (src == NULL))
	{  
		return NULL; 
	} 
	//printf("here0 %s\n",src); 
	__IO unsigned char *desc1 = (unsigned char*)desc; 
	__IO unsigned char *src1 = (unsigned char*)src; 
	//printf("here0 %s\n",src1);
	while(size-- >0) 
	{
		
		*desc1 = *src1;  
		//printf("here1 %c %c\n",*desc1,*src1); 
		desc1++;  
		src1++; 
	} 
	return desc;
}

static void User_Main_Init(void)
{
	HAL_Init();
	
	//User_IWDG_Init();
	
	User_UART_Init();
	
	GPIO_CLK_ENABLE();
	
	while(cnt < 40)
	{
		User_GPIO_Init(sensor[cnt].gpiox, sensor[cnt].pin, 1);                // 传感器io口初始化
		User_GPIO_Init(led[cnt].gpiox, led[cnt].pin, 0);                      // LED灯io口初始化
		
		// 获取传感器io口初始电平状态，并保存在数组中
		if(HAL_GPIO_ReadPin(sensor[cnt].gpiox, sensor[cnt].pin) == SET)
			sensor_state[cnt] = '1';
		else
			sensor_state[cnt] = '0';
		++cnt;
	}  
	
	// 输出传感器io口初始电平
	//printf("sensor_state:%s\n",sensor_state);
	cnt = 0;
	
	User_Check_MCU_Reset_Reason();
}

static void User_IWDG_Init(void)
{
	uint32_t tickstart = 0U;
	
	/* (1) Enable the LSI */
	/* (2) Wait while it is not ready */
	tickstart = HAL_GetTick();
	RCC->CSR |= RCC_CSR_LSION; /* (1) */
	while((RCC->CSR & RCC_CSR_LSIRDY)!=RCC_CSR_LSIRDY) /* (2) */
	{ 
		/* add time out here for a robust application */
		if((HAL_GetTick() - tickstart ) > LSI_TIMEOUT_VALUE)
        {
			HAL_NVIC_SystemReset();
        }
	}
	/* Configure & Start the IWDG peripheral */
	/* Set counter reload value to obtain ~1.6 sec. IWDG TimeOut.
     IWDG counter clock Frequency = uwLsiFreq (~40KHz)
     Set Prescaler to 16 (IWDG_PRESCALER_16)
     Timeout Period = (Reload Counter Value  * 16) / uwLsiFreq
	 Timeout Period = (0xFFFU  * 16) / uwLsiFreq
	*/
	/* Enable IWDG. LSI is turned on automaticaly */
	IWDG->KR = IWDG_KEY_ENABLE;
	/* Enable write access to IWDG_PR, IWDG_RLR and IWDG_WINR registers by writing
	0x5555 in KR */
	IWDG->KR = IWDG_KEY_WRITE_ACCESS_ENABLE;
	/* Write to IWDG registers the Prescaler & Reload values to work with */
	IWDG->PR = IWDG_PRESCALER_16;
	IWDG->RLR = 0xFFFU;

	/* Check pending flag, if previous update not done, return timeout */
	tickstart = HAL_GetTick();
	/* Wait for register to be updated */
	while(IWDG->SR != RESET)
	{
		if((HAL_GetTick() - tickstart ) > USER_IWDG_DEFAULT_TIMEOUT)
		{
			HAL_NVIC_SystemReset();
		}
	}
	IWDG->KR = IWDG_KEY_RELOAD;
}
static void User_Feed_IWDG(void)
{
	IWDG->KR = IWDG_KEY_RELOAD;
}

static void GPIO_CLK_ENABLE(void)
{
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOG_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
}

static void User_Check_MCU_Reset_Reason(void)
{
	if(__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST) != RESET)
	{
		printf("MCU_IWDG_RST.\n");
	}
	/* Clear reset flags in any cases */
	__HAL_RCC_CLEAR_RESET_FLAGS();
}


SCAN_CODE_LIST_MEM_TypeDef g_stScanCodeListMem;

uint8_t ParseScanCodeJson(const char* pszJsonText)
{
    cJSON   *root, *result;
	char* p;
    uint8_t ret = false;
	uint8_t msg_id;

    //将json字符串解析成json结构体
    root= cJSON_Parse(pszJsonText);
	
	if(root)
	{
		//获取报文id
		msg_id = cJSON_GetObjectItem(root, "id")->valueint;
		
		//从根节点获取type元素的值 字符串型
		p = cJSON_GetObjectItem(root, "type")->valuestring;

		//从根节点获取body节点
		result = cJSON_GetObjectItem(root, "body");
	
		// 判断协议操作的是不是led灯
		if(!strncmp(p, "light", 5))
		{
			
			if (result)
			{ 
				//从body节点获取各个元素的值
				
				g_stScanCodeListMem.LED_ID =  cJSON_GetObjectItem(result, "no")->valueint; //int 型
				g_stScanCodeListMem.STATE = cJSON_GetObjectItem(result, "state")->valuestring;//字符串型


				//保存扫描用户的名字  把ID值也作为一个参数存入
				//WriteScanCodeName(g_stScanCodeListMem.pName, g_stScanCodeListMem.cID);

				printf("\r\n");
				printf("led_id:%d\t", g_stScanCodeListMem.LED_ID);       
				printf("state:%s", g_stScanCodeListMem.STATE);              
				printf("\r\n");       
				 
				if(g_stScanCodeListMem.LED_ID > 39)  
					
						printf("{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":1}}#\n", msg_id);
					else
						
						// 指令为true，打开led灯
						if(!strncmp(g_stScanCodeListMem.STATE,"true",5))
							
							User_Led_Control(g_stScanCodeListMem.LED_ID, 1, msg_id);
						else 	
							// 指令为false，关闭led灯
							if(!strncmp(g_stScanCodeListMem.STATE,"false",5))
								
								User_Led_Control(g_stScanCodeListMem.LED_ID, 0, msg_id);				
			}
			else
								
				printf("{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":2},\"crc\":1}#\n", msg_id);
		}
		
		// 判断协议操作的是不是报警器
		else if(!strncmp(p, "alarm", 5))
		{
			/*报警器*/
			if (result)
			{ 
				//从body节点获取各个元素的值
				
				g_stScanCodeListMem.STATE = cJSON_GetObjectItem(result, "state")->valuestring;//字符串型


				//保存扫描用户的名字  把ID值也作为一个参数存入
				//WriteScanCodeName(g_stScanCodeListMem.pName, g_stScanCodeListMem.cID);

				printf("\r\n");
				printf("type:alarm\t");       
				printf("state:%s", g_stScanCodeListMem.STATE);              
				printf("\r\n");       
				
				// 指令为false，打开报警器
				if(!strncmp(g_stScanCodeListMem.STATE,"true",5))
					
					User_Alarm(1, msg_id);
				else 	
					// 指令为false，关闭报警器
					if(!strncmp(g_stScanCodeListMem.STATE,"false",5))
						
						User_Alarm(0, msg_id);
			}				
			else
						
				printf("{\"id\":%d,\"direction\":1,\"type\":\"alarm\",\"body\":{\"result\":1},\"crc\":1}#\n", msg_id);				
		}
	}
	else
								
		printf("{\"id\":%d,\"direction\":1,\"type\":\"%s\",\"body\":{\"result\":2},\"crc\":1}#\n", msg_id, cJSON_GetObjectItem(root, "type")->valuestring);
	
	//释放资源        
	cJSON_Delete(root);
	
    return ret;
}


static void User_Sensor_Check(void)
{
	if(User_Timer_Start_Check(TIMER_ID_SCAN_SENSOR) == TIMER_STOP)
	{
		
		// 间隔1s就扫描一次传感器状态
		User_Timer_Start(TIMER_ID_SCAN_SENSOR,1000);
	}
    if(User_Timer_Start_Expire_Check(TIMER_ID_SCAN_SENSOR))
    {
		// 获取状态发生变改变的传感器
		while(cnt < 40)
		{
			// 传感器低电平变高电平
			if(HAL_GPIO_ReadPin(sensor[cnt].gpiox, sensor[cnt].pin) == SET)
			{
				if(sensor_state[cnt] == '0')
				{
					sensor_state[cnt] = '1';
					//printf("sensor_id:%d\t original:0\t now:1\n", cnt);
				}
			}
			// 传感器高电平变低电平
			else
			{
				if(sensor_state[cnt] == '1')
				{
					sensor_state[cnt] = '0';
				//	printf("{\"id\":11,\"direction\":0,\"type\":\"input\",\"body\":{\"no\":%d},\"crc\":1}#\n", cnt);
					cnt_tmp = cnt;
					ProtocalSendSwitch.sensor_scan_result_switch = SWITCH_ON;
				}
			}

			++cnt;			
		}
		cnt = 0;
		User_Timer_Reflesh(TIMER_ID_SCAN_SENSOR);
	}
}


static void User_Led_Control(int LED_ID, uint8_t STATE, uint8_t MSG_ID)
{
	// 接收指令对led进行相应操作 ，并判断操作是否成功
	printf("\r\n");
	
	if(STATE == 1)
	{
		HAL_GPIO_WritePin(led[LED_ID].gpiox, led[LED_ID].pin, GPIO_PIN_SET);   
		
		if(HAL_GPIO_ReadPin(led[LED_ID].gpiox, led[LED_ID].pin))
			
			//printf("{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":0},\"crc\":1}#\n", MSG_ID);
		{
			char BufferWithoutCrc[1024] = {0};
			snprintf(BufferWithoutCrc,1000,"{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":0}}",MSG_ID);
			//printf("BufferWithoutCrc %s\n",BufferWithoutCrc);
			uint32_t crc = CheckCrc(BufferWithoutCrc,strlen(BufferWithoutCrc));
			snprintf(BufferWithoutCrc,1000,"{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":0},\"crc\":%d}#",MSG_ID,crc);
			printf("%s\n",BufferWithoutCrc);
		}
		else
			
			printf("{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"mac\":\"aa bb cc dd ee ff\"},\"crc\":1,\"message\":\"open led fail\"}#\n", MSG_ID);

	}
	else
	{
		HAL_GPIO_WritePin(led[LED_ID].gpiox, led[LED_ID].pin, GPIO_PIN_RESET);
		
		if(!HAL_GPIO_ReadPin(led[LED_ID].gpiox, led[LED_ID].pin))
		//printf("{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":0},\"crc\":1}#\n", MSG_ID);
		{
			char BufferWithoutCrc[1024] = {0};
			snprintf(BufferWithoutCrc,1000,"{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":0}}",MSG_ID);
			//printf("BufferWithoutCrc %s\n",BufferWithoutCrc);
			uint32_t crc = CheckCrc(BufferWithoutCrc,strlen(BufferWithoutCrc));
			snprintf(BufferWithoutCrc,1000,"{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"result\":0},\"crc\":%d}#",MSG_ID,crc);
			printf("%s\n",BufferWithoutCrc);
		}
		else
			
			printf("{\"id\":%d,\"direction\":1,\"type\":\"light\",\"body\":{\"mac\":\"aa bb cc dd ee ff\"},\"crc\":1,\"message\":\"close led fail\"}#\n", MSG_ID);
		
	}
	printf("\r\n");
}

void User_Alarm(uint8_t _switch, uint8_t msg_id)
{
	if(_switch == 1)
	{
		/*打开报警器*/
		
		if(/*报警器成功打开*/1)
			
			printf("{\"id\":%d,\"direction\":0,\"type\":\"alarm\",\"body\":{\"result\":0},\"crc\":1}#\n",msg_id);
		else
			
			printf("{\"id\":%d,\"direction\":0,\"type\":\"alarm\",\"body\":{\"mac\":\"aa bb cc dd ee ff\"},\"crc\":1,\"message\":\"open alarm fail\"}#\n", msg_id);
	}
	
	else if(_switch == 0)
	{
		/*关闭报警器*/

		if(/*报警器成功关闭*/1)
			
			printf("{\"id\":%d,\"direction\":0,\"type\":\"light\",\"body\":{\"result\":0},\"crc\":1}#\n", msg_id);
		else
			
			printf("{\"id\":%d,\"direction\":0,\"type\":\"alarm\",\"body\":{\"mac\":\"aa bb cc dd ee ff\"},\"crc\":1,\"message\":\"close alarm fail\"}#\n", msg_id);
	}
	
	//未登录放料
	else
	{
		//打开报警器
	}
}

void DeviceLogin(loginstatus * DeviceLoginStatus)
{
	if(*DeviceLoginStatus == LOGOUT)
	{
		printf("+++");
		//printf("+++\r\n");
		int count=0;
		uint8_t enumMode;
		do
		{
			HAL_Delay(1000);
			if(esp8266_mode(enumMode)==false)count++;
			if(esp8266_Rst()==false)count++;
			else HAL_Delay(2000);
			if(esp8266_Join_AP(test.pSSID,test.pPassWord)==false)count++;
			else
			{
				if(esp8266_Get_Ip()==false)count++;
				if(CopyContentBetweenTwoSymbols(deviceinfo.ip,buffer,"STAIP,\"","\"") == NULL)count++;
				//else printf("DEVICEIP %s\n",deviceinfo.ip);
				if(CopyContentBetweenTwoSymbols(deviceinfo.mac,buffer,"STAMAC,\"","\"") == NULL)count++;
				//else printf("DEVICEMAC %s\n",deviceinfo.mac);
			}
			if(esp8266_link_Server(test.ip)==false)count++;
			if(esp8266_UnvarnishSend()==false)count++;
			if(esp8266_DateTC()==false){count++;}
			if(count!=0) printf("+++");
			//if(count!=0) printf("+++\r\n");
		}while(count!=0);
		*DeviceLoginStatus = WAITFOR_RESPOND;
		ProtocalSendSwitch.login_info_switch = SWITCH_ON;
	}
}
bool esp8266_send_cmd(char *cmd,char *reply,uint32_t waittime)
{
	int flag=0;
    char cstr[20];
    memset(buffer,0,SIZE_OF_FULL_BUFFER);

    printf("%s\r\n",cmd);
    uint32_t tickstart = 0U;
	tickstart = HAL_GetTick();
	while(strstr(buffer,reply) == NULL)
	{ 
		/* add time out here for a robust application */
		if((HAL_GetTick() - tickstart ) > waittime)
        {
			tickstart = HAL_GetTick();
			memset(buffer,0,SIZE_OF_FULL_BUFFER);
			printf("%s\r\n",cmd);
			flag++;
			if(flag>3) return false;
        }
	} 
	//printf("header %s\r\n tailer",buffer);
	return true;
}

bool esp8266_mode(uint8_t enumMode)
{
	return esp8266_send_cmd("AT+CWMODE=1","OK",1000);
}
bool esp8266_Rst(void)
{
	return esp8266_send_cmd("AT+RST","OK",2500);
}
bool esp8266_Join_AP(char *pSSID,char *pPassWord)
{
    char cCmd[120];
	sprintf(cCmd,"AT+CWJAP=\"%s\",\"%s\"",pSSID,pPassWord);
    return esp8266_send_cmd(cCmd,"OK",15000);
}
bool esp8266_Get_Ip(void)
{
    return esp8266_send_cmd("AT+CIFSR","OK",2000);
}
bool esp8266_link_Server(char *ip)
{
	char cStr[100],cCmd[120];
	sprintf(cStr,"\"%s\",\"%s\",8086","TCP",ip);//8080
	sprintf(cCmd,"AT+CIPSTART=%s",cStr);
	return esp8266_send_cmd(cCmd,"OK",5000);
}
bool esp8266_UnvarnishSend(void)
{
	bool return_flag;
	return esp8266_send_cmd("AT+CIPMODE=1","OK",1000);
	
}

bool esp8266_DateTC(void)
{
	return esp8266_send_cmd("AT+CIPSEND","OK",1000);
}
/* 将位于字符串中符号1和符号2件的字符串复制处理*/
char * CopyContentBetweenTwoSymbols(char *dest, char *src,char *symbol_one,char *symbol_two)
{	
	char *symbol_one_addr = NULL;	
	char *symbol_two_addr = NULL; 	
	symbol_one_addr = strstr(src, symbol_one);	
	symbol_two_addr = strstr(symbol_one_addr + strlen(symbol_one), symbol_two); 	
	if(symbol_one_addr == NULL || symbol_two_addr == NULL || symbol_one_addr > symbol_two_addr)	
	{
		printf("not found.\n");
		return NULL;
	}	
	else	
	{		
		symbol_one_addr += strlen(symbol_one);
		memcpy(dest, symbol_one_addr, symbol_two_addr-symbol_one_addr);/*dest不能以 char * ？ 定义*/
	} 	
	return dest;
}


	
	
	
	
	