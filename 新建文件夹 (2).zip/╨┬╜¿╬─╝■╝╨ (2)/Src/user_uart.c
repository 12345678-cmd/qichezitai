/**
  ******************************************************************************
  * @file               uart.c            
  * @last@modification  Jiangwholesome  
  * @version            V1.0        
  * @date               2019/7/31          
  * @brief                        
  *                   
  *                    
  *                    
  ******************************************************************************
*/
/* Includes ------------------------------------------------------------------*/
#include <string.h>

#include "main.h"
#include "user_uart.h"
#include "user_gpio.h"
#include "user_uart_data_analyze.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/*
1. 结构体在两个平台库中名称和定义完全一样
2. 不一样需要加平台宏
*/
///* UART handler declaration */
//UART_HandleTypeDef UartHandle;
UART_STATE_RX Uart_State_Rx = UART_STATE_RX_READY;

command_para Command_Param = {NULL,NULL};
char rxbuffer[SIZE_OF_FULL_BUFFER] = {0};
char buffer[SIZE_OF_FULL_BUFFER] = {0};
char Rx_Buffer_Tmp[SIZE_OF_FULL_BUFFER] = {0};
uint8_t Uart_Flag = 1;

/* Private function prototypes -----------------------------------------------*/
/*内部函数
当转换平台时，要么增加平台代码
或者定义了未被使用
*/
/*平台变化变代码*/
static void User_UART_MspInit(void);
static void User_UART_MspDeInit(void);
static void User_UART_RxCallback(void);
static void User_UART_Transmit(uint8_t *pData,uint32_t Timeout);
static void User_UART_WaitOnFlagUntilTimeout(uint32_t Flag,uint32_t Tickstart, uint32_t Timeout);
/* Private functions ---------------------------------------------------------*/

void User_UART_Init(void)
{
	//UartHandle.Instance   = USARTx;

	rxbuffer[SIZE_OF_DATA_BUFFER] = 1;
	buffer[SIZE_OF_DATA_BUFFER] = 1;
    
    User_UART_MspInit();
     /* Disable the Peripheral 
    __HAL_UART_DISABLE(&UartHandle);*/
    USARTx->CR1 &=  (~USART_CR1_UE);
    
    /* Configure USART */
    /* (1) oversampling by 16, 9600 baud */
    /* (2) 8 data bit, 1 start bit, 1 stop bit, no parity*/
    USARTx->BRR = (16000000 + 115200/2)/ 115200; /* (1) */
    /*USARTx->BRR = (2000000 + 9600/2)/ 9600;  (1) */

      /* Enable the Peripheral 
    __HAL_UART_ENABLE(&UartHandle);*/
    USARTx->CR1 |=  USART_CR1_UE;
    
    USARTx->CR1 = USART_CR1_RXNEIE | USART_CR1_RE |  USART_CR1_UE | USART_CR1_TE; 
}


void User_UART_Data_Analyze_Respond(void)
{
    /*解析回复，目前的做法只解析了接收数据的第一条有效协议
    没有考虑时间临近的两条以上数据的情况*/   
    /*200ms扫描一次*/
    /*200ms后发现数据有头有尾，
        1.开始抄数据
        2.开始新一轮接收
        3.开始解析*/
	if(User_Timer_Start_Check(TIMER_ID_UART_DATA_ANALYZE) == TIMER_STOP)
	{
		User_Timer_Start(TIMER_ID_UART_DATA_ANALYZE,100);
	}
    if(User_Timer_Start_Expire_Check(TIMER_ID_UART_DATA_ANALYZE))
    {
		//printf("test\n");
		if(Uart_State_Rx == UART_STATE_RX_READY)
		{
			if(Uart_Flag == 1)
			{
				if(rxbuffer[SIZE_OF_DATA_BUFFER] == 1)
				{
					Uart_State_Rx = UART_STATE_RX_COPY;
					/*strstr*/
					/*数据长度可以统计到目前接收的*/
					strncpy(Rx_Buffer_Tmp,rxbuffer,SIZE_OF_DATA_BUFFER);
					memset(rxbuffer,0,SIZE_OF_FULL_BUFFER);
					Uart_State_Rx = UART_STATE_RX_READY;
					User_UART_Data_Analyze_String(Rx_Buffer_Tmp,&Command_Param); 
					//memset(Rx_Buffer_Tmp,0,SIZE_OF_FULL_BUFFER);  
					Uart_Flag = 0;
				}
			}
			User_Timer_Reflesh(TIMER_ID_UART_DATA_ANALYZE);
		}
    }
}



static void User_UART_MspInit(void)
{  
	/*也可以由GPIO部分来做，但是为了模块分离*/
	USARTx_TX_GPIO_CLK_ENABLE();
	USARTx_RX_GPIO_CLK_ENABLE();
	/* Enable USART clock */
	USARTx_CLK_ENABLE(); 
	  GPIO_InitTypeDef  GPIO_InitStruct;
	 /*##-2- Configure peripheral GPIO ##########################################*/
  /* UART TX GPIO pin configuration  */
  GPIO_InitStruct.Pin       = USARTx_TX_PIN;
  GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull      = GPIO_PULLUP;
  GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = USARTx_TX_AF;
  HAL_GPIO_Init(USARTx_TX_GPIO_PORT, &GPIO_InitStruct);

  /* UART RX GPIO pin configuration  */
  GPIO_InitStruct.Pin = USARTx_RX_PIN; 
  GPIO_InitStruct.Alternate = USARTx_RX_AF;
  HAL_GPIO_Init(USARTx_RX_GPIO_PORT, &GPIO_InitStruct);
	/*## Configure the NVIC for UART ########################################*/
	/* NVIC for USART */
	HAL_NVIC_SetPriority(USARTx_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(USARTx_IRQn);
}
/*由于设置了默认值，屏蔽项目和平台的时候，不需要屏蔽这里*/
static void User_UART_MspDeInit(void)
{
	/*## Reset peripherals ##################################################*/
	USARTx_FORCE_RESET();
	USARTx_RELEASE_RESET();

	/*##-2- Disable peripherals and GPIO Clocks #################################*/
	HAL_GPIO_DeInit(GPIO_PORT_MCU_UTX_URX, GPIO_PIN_MCU_UTX);
	HAL_GPIO_DeInit(GPIO_PORT_MCU_UTX_URX, GPIO_PIN_MCU_URX);

	/*##-3- Disable the NVIC for UART ##########################################*/
	HAL_NVIC_DisableIRQ(USARTx_IRQn);
}
/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE 
{
	/* Place your implementation of fputc here */
	/* e.g. write a character to the USART and Loop until the end of transmission */
	//HAL_UART_Transmit(&UartHandle, (uint8_t *)&ch, 1, 0xFFFF);
    User_UART_Transmit((uint8_t *)&ch, 0xFFFF);

	return ch;
}
static void User_UART_Transmit(uint8_t *pData,uint32_t Timeout)
{
    /* Init tickstart for timeout managment*/
    uint32_t tickstart = HAL_GetTick();
    User_UART_WaitOnFlagUntilTimeout(UART_FLAG_TXE,tickstart, Timeout);
    USARTx->DR = (*pData & (uint8_t)0xFFU);
    User_UART_WaitOnFlagUntilTimeout(UART_FLAG_TC,tickstart, Timeout);
}
static void User_UART_WaitOnFlagUntilTimeout(uint32_t Flag,uint32_t Tickstart, uint32_t Timeout)
{
    /* Wait until flag is set */
    while((((USARTx->SR & (Flag)) == (Flag)) ? SET : RESET) == RESET)
    {
        /* Check for the Timeout */
        if(Timeout != HAL_MAX_DELAY)
        {
          if((Timeout == 0U) || ((HAL_GetTick()-Tickstart) > Timeout))
          {
            /* Disable TXE, RXNE, PE and ERR (Frame error, noise error, overrun error) interrupts for the interrupt process */
            CLEAR_BIT(USARTx->CR1, (USART_CR1_RXNEIE | USART_CR1_PEIE | USART_CR1_TXEIE));
            CLEAR_BIT(USARTx->CR3, USART_CR3_EIE);
          }
        }
    }
}
void User_UART_IRQHandler(void)
{
	uint32_t isrflags   = READ_REG(USARTx->SR);
	uint32_t cr1its     = READ_REG(USARTx->CR1);
	/* UART in mode Receiver ---------------------------------------------------*/
	if(((isrflags & USART_SR_RXNE) != RESET) && ((cr1its & USART_CR1_RXNEIE) != RESET))
	{
		//HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_0);
		User_UART_RxCallback();
		return;
	}
}
/**
  * @brief  Rx Transfer callback
  * @param  UartHandle: UART handle
  * @note   This example shows a simple way to report end ofbRx transfer, and you can add your own implementation.
  * @retval None
  */
static void User_UART_RxCallback(void)
{
    /*获取本次中断后接收到的字节*/
    uint8_t tmp_byte = (uint8_t) READ_REG(USARTx->DR);
    /*等待接收中断标志被清零*/
    while(HAL_IS_BIT_SET(USARTx->SR, UART_FLAG_RXNE))
    {
    } 
    if(Uart_State_Rx != UART_STATE_RX_COPY)
    {
        Uart_Flag = 1;
        Uart_State_Rx = UART_STATE_RX_BUSY;
        static uint16_t i = 0; 
        if(i < SIZE_OF_DATA_BUFFER && rxbuffer[SIZE_OF_DATA_BUFFER] == 1)
        {
            rxbuffer[i] = tmp_byte;
        }
        else 
        {
            i = 0;
            rxbuffer[i] = tmp_byte;
            rxbuffer[SIZE_OF_DATA_BUFFER] = 1;
        }
        i++;
        Uart_State_Rx = UART_STATE_RX_READY;
    }
	
	static uint16_t j = 0; 
	if(j < SIZE_OF_DATA_BUFFER && buffer[SIZE_OF_DATA_BUFFER] == 1)
	{
		buffer[j] = tmp_byte;
	}
	else 
	{
		j = 0;
		buffer[j] = tmp_byte;
		buffer[SIZE_OF_DATA_BUFFER] = 1;
	}
	j++;
}


void User_UART_Power_Config(void)
{
    /* Disable the Peripheral */
    USARTx->CR1 &=  (~USART_CR1_UE);
    
    USARTx->CR1 = 0x0U;
    USARTx->CR2 = 0x0U;
    USARTx->CR3 = 0x0U;

    /* DeInit the low level hardware */
    User_UART_MspDeInit(); 
    
    USARTx_CLK_DISABLE();
}


/*****************************END OF FILE***********************/
