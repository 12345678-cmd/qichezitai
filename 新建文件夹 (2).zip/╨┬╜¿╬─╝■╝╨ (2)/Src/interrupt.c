 /**
  ******************************************************************************
  * @file     interrupt.c      
  * @author   Jiangwholesome  
  * @version  V1.0  
  * @date     2019/7/31    
  * @brief        
  *                   
  *                    
  *                    
  ******************************************************************************
*/
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "user_uart.h"
#include "interrupt.h"
/******************************************************************************/
/*            Cortex-M0 Processor Exceptions Handlers                         */
/******************************************************************************/

/*Peripheral handler declared user files */

extern RTC_HandleTypeDef    RtcHandle;
/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
	HAL_NVIC_SystemReset();
}


/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}


/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
  HAL_IncTick();//系统提供的HAL_Delay();函数需要用到这个，去掉会死在循环里面
}
/*不同芯片向量表存储名称可能不一样
查看startup_stm32X0xx.s*/
/******************************************************************************/
/*                 STM32F0xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f0xx.s).                                               */
/******************************************************************************/
/**
  * @brief  This function handles UART interrupt request.  
  * @param  None
  * @retval None
  * @Note   This function is redefined in "main.h" and related to DMA  
  *         used for USART data transmission     
  */
void USARTx_IRQHandler(void)
{
	/*库函数不太适用，做修改，放在用户程序内*/
	User_UART_IRQHandler();
}

/**
  * @brief  This function handles TIM interrupt request.
  * @param  None
  * @retval None
  */

/**
  * @brief  This function handles RTC Alarm interrupt request.
  * @param  None
  * @retval None
  */
