/**
  ******************************************************************************
  * @file               timer.c            
  * @last@modification  Jiangwholesome  
  * @version            V1.0        
  * @date               2019/7/31          
  * @brief                        
  *                   
  *                    
  *                    
  ******************************************************************************
*/
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "user_timer.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Prescaler declaration */
uint32_t uwPrescalerValue = 0;
timer_man  Timer_Manage = {0};
timer_man * TimerPtr = &Timer_Manage;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
static void User_TIM2_MspInit(void);
static void User_TIM2_PeriodElapsedCallback(void);

void User_Timer_Start(timer_ID_reg TimerID,uint32_t Expire_Time)
{
	TimerPtr->Timer_Status[TimerID] = TIMER_START;
	TimerPtr->Start_Time[TimerID]   = HAL_GetTick();
	TimerPtr->Expire_Time[TimerID]  = Expire_Time;
}
uint32_t User_Timer_Get_Expire_Time(timer_ID_reg TimerID)
{
	return TimerPtr->Expire_Time[TimerID];
}
uint8_t User_Timer_Start_Check(timer_ID_reg TimerID)
{
	return TimerPtr->Timer_Status[TimerID];
}

void User_Timer_Stop(timer_ID_reg TimerID)
{
	TimerPtr->Timer_Status[TimerID] = TIMER_STOP;
}
uint32_t User_Timer_Elapsed_Time(timer_ID_reg TimerID)
{
	return  ((HAL_GetTick() >= TimerPtr->Start_Time[TimerID]) ? \
			 (HAL_GetTick() - TimerPtr->Start_Time[TimerID]) : \
	         ((0xFFFFFFFFu - TimerPtr->Start_Time[TimerID]) + HAL_GetTick() + 1u));
}
uint8_t User_Timer_Expire_Check(timer_ID_reg TimerID)
{
	return (User_Timer_Elapsed_Time(TimerID) >= (TimerPtr->Expire_Time[TimerID]));
}
uint8_t User_Timer_Start_Expire_Check(timer_ID_reg TimerID)
{
	if(User_Timer_Start_Check(TimerID) == TIMER_START)
	{
		return (User_Timer_Elapsed_Time(TimerID) >= (TimerPtr->Expire_Time[TimerID]));
	}
	return TIMER_STOP;
}
/*考虑增加刷新同时更改时间的代码*/
void User_Timer_Reflesh(timer_ID_reg TimerID)
{
	TimerPtr->Start_Time[TimerID] = HAL_GetTick();
}

void User_TIM2_Init(void)
{
	/*10ms*/
	/* Compute the prescaler value to have TIMx counter clock equal to 10kHz */
	uwPrescalerValue = (uint32_t)(SystemCoreClock / 10000) - 1;

	/* Initialize TIMx peripheral as follows:
	   + Period = 100 - 1
	   + Prescaler = (SystemCoreClock/10000) - 1
	   + ClockDivision = 0
	   + Counter direction = Up
	*/
    User_TIM2_MspInit();
    /* Select the Counter Mode */
    /*
    TIMx->CR1 &= ~(TIM_CR1_DIR | TIM_CR1_CMS);
    TIMx->CR1 |= TIM_COUNTERMODE_UP;*/
    
    /* Set the clock division */
    /*
    TIMx->CR1 &= ~TIM_CR1_CKD;
    TIMx->CR1 |= (uint32_t)0;*/
    
    /* Set the Autoreload value */
    TIMx->ARR = 10000*TIM2_UPDATE_TIME/1000 - 1;

    /* Set the Prescaler value */
    TIMx->PSC = (uint32_t)uwPrescalerValue;

    /* Generate an update event to reload the Prescaler value immediatly */
    TIMx->EGR = TIM_EGR_UG;
    
	/*##-2- Start the TIM Base generation in interrupt mode ####################*/
    /* Enable the TIM Update interrupt */
	TIMx->DIER |= TIM_IT_UPDATE;
    /* Enable the Peripheral */
    TIMx->CR1  |= TIM_CR1_CEN;
}

void User_TIM2_Power_Config(void)
{
    if((TIMx->CCER & TIM_CCER_CCxE_MASK) == 0) 
    { 
        TIMx->CR1 &= ~(TIM_CR1_CEN); 
    } 
	TIMx_CLK_DISABLE();
}

void User_TIM2_IRQHandler(void)
{
      /* TIM Update event */
    if((TIMx->SR & TIM_FLAG_UPDATE) == TIM_FLAG_UPDATE)
    {
        if((TIMx->DIER & TIM_IT_UPDATE) == TIM_IT_UPDATE)
        {
            TIMx->SR = (~TIM_IT_UPDATE);
            User_TIM2_PeriodElapsedCallback();
        }
    }
}

/**
  * @brief TIM MSP Initialization
  *        This function configures the hardware resources used in this example:
  *        - Peripheral's clock enable
  * @retval None
  */
static void User_TIM2_MspInit(void)
{
    /*##-1- Enable peripheral clock #################################*/
	/* TIMx Peripheral clock enable */
	TIMx_CLK_ENABLE();

	/*##-2- Configure the NVIC for TIMx ########################################*/
	/* Set the TIMx priority */
	HAL_NVIC_SetPriority(TIMx_IRQn, 2, 0);

	/* Enable the TIMx global Interrupt */
	HAL_NVIC_EnableIRQ(TIMx_IRQn);
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @retval None
  */

static void User_TIM2_PeriodElapsedCallback(void)
{
}

/*****************************END OF FILE***********************/
