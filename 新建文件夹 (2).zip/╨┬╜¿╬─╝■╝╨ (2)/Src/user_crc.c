/**
  ******************************************************************************
  * @file               user_crc.c            
  * @last@modification  Jiangwholesome  
  * @version            V1.0        
  * @date               2019/8/9          
  * @brief                        
  *                   
  *                    
  *                    
  ******************************************************************************
*/
/* Includes ------------------------------------------------------------------*/
#include "user_crc.h" 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*
��վ����https://crccalc.com/
{"id":1,"direction":0,"type":"light","body":{"no":24,"state":true}}  44
��������
{\"id\":1,\"direction\":0,\"type\":\"light\",\"body\":{\"no\":24,\"state\":true}}


{"id":2,"direction":0,"type":"input","body":{"no":21}}
{\"id\":2,\"direction\":0,\"type\":\"input\",\"body\":{\"no\":21}}  80


{"id":2,"direction":1,"type":"login","body":{"result":0}}   49
{\"id\":2,\"direction\":1,\"type\":\"login\",\"body\":{\"result\":0}}
*/



char CheckCrc(char data[], uint32_t nbrOfBytes)
{
	char bit;        // bit mask
	char crc = 0x00; // calculated checksum
	uint32_t byteCtr;    // byte counter

	// calculates 8-Bit checksum with given polynomial
	for(byteCtr = 0; byteCtr < nbrOfBytes; byteCtr++)
	{
		crc ^= (data[byteCtr]);
		for(bit = 8; bit > 0; --bit) 
		{
			if(crc & 0x80) 
			{
				crc = (crc << 1) ^ 0x07;
			} 
			else
			{
				crc = (crc << 1);
			}
		}
	}
	return crc;
}
/*****************************END OF FILE***********************/
