/**
  ******************************************************************************
  * @file               uart_data_analyze.c            
  * @last@modification  Jiangwholesome  
  * @version            V1.0        
  * @date               2019/7/31         
  * @brief                        
  *                   
  *                    
  *                    
  ******************************************************************************
*/
/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include <stdbool.h>
#include "main.h"
#include "cJSON.h"
#include "cJSON_Utils.h"
#include "user_crc.h"
#include "user_timer.h"
#include "user_cmd_res_func.h"
#include "user_uart_data_analyze.h"

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
static char * User_UART_Data_Find_Header(char * Buffer);

static char * User_UART_Data_Find_Tail(char * Buffer);

bool JsonCrcCheck(char* Data,command_para * JsonPara);

extern loginstatus DeviceLoginStatus;
extern protocal_send_switch ProtocalSendSwitch;
/* Exported functions --------------------------------------------------------*/
void User_UART_Data_Analyze_String(char * Buffer ,command_para * Command_Param)
{
	//cJSON * json = NULL;
	//char *json_data = NULL;
	/*头部查找,找完指向协议号处*/
	while(*Buffer != 0)
	{
        Buffer = User_UART_Data_Find_Header(Buffer);
        if(Buffer == NULL)
        {
            return;
        }
        else
        {
            Command_Param->Header = Buffer;
        }
        /*查找尾部*/
        Buffer = User_UART_Data_Find_Tail(Buffer);
        if(Buffer == NULL)
        {    
            return;
        }
        else
        {
			//printf("data %s\n",Command_Param->Header);
            Command_Param->Tail = Buffer;
        }
		/*JSON协议解析*/
		char Json_data_tmp[1000] = {0};
		memcpy(Json_data_tmp,Command_Param->Header,strlen(Command_Param->Header));
		
		/*校验不通过，返回*/
		command_para JsonPara = {NULL,NULL,0,0,NULL,NULL,0};
		if(JsonCrcCheck(Json_data_tmp,&JsonPara) == false) return;/*不能直接把Command_Param->Header放在这里？*/
		
		/*登录信息如果得到回复，就停止发送登录信息*/
		if(strncmp(JsonPara.JsonType,"login",5) == 0 && JsonPara.JsonDir == 1)
		{
			DeviceLoginStatus = LOGIN;/*状态为登录状态*/
			ProtocalSendSwitch.login_info_switch = SWITCH_OFF;/*停止发送*/
			User_Timer_Stop(TIMER_ID_SEND_LOGIN_INFO);
		}
		if(strncmp(JsonPara.JsonType,"input",5) == 0 && JsonPara.JsonDir == 1)
		{
			ProtocalSendSwitch.sensor_scan_result_switch = SWITCH_OFF;/*停止发送*/
			User_Timer_Stop(TIMER_ID_SEND_SENSOR_SCAN_RESULT);
		}
		
		ParseScanCodeJson(Command_Param->Header);
		
		/*还需要添加长度检查*/
        Buffer = Command_Param->Tail + 2;
    }
}
bool JsonCrcCheck(char* Data,command_para * JsonPara)
{
	cJSON   *root;
	root = cJSON_Parse(Data);
	char JsonWithoutCrc[1024] = {0};
	if(root)
	{
		JsonPara->JsonID = cJSON_GetObjectItem(root, "id")->valueint;
		
		JsonPara->JsonDir = cJSON_GetObjectItem(root, "direction")->valueint;
		
		JsonPara->JsonType = cJSON_GetObjectItem(root, "type")->valuestring;
		
		JsonPara->JsonBody = cJSON_GetObjectItem(root, "body");
		//获取报文crc
		JsonPara->JsonCrc = cJSON_GetObjectItem(root, "crc")->valueint;
		/*计算不包含crc段的数据的crc，和crc段的值比较*/
		snprintf(JsonWithoutCrc,1000,\
		"{\"id\":%d,\"direction\":%d,\"type\":\"%s\",\"body\":%s}",\
		JsonPara->JsonID,\
		JsonPara->JsonDir,\
		JsonPara->JsonType,\
		cJSON_Print(JsonPara->JsonBody));/*用cJSON_Print(cJSON_GetObjectItem(root, "body"))不行？*/
		//printf("JsonWithoutCrc snprintf %s\n",JsonWithoutCrc);
		if(CheckCrc(JsonWithoutCrc,strlen(JsonWithoutCrc)) == JsonPara->JsonCrc)
		{
			return true;
		}
		else
		{
			printf("{\"json\":\"%s\",\"message\":\"crc error\"}",Data);
			return false;
		}
	}
	else
	{
		printf("no root.\n");
		return false;
	}
}

/* Private functions ---------------------------------------------------------*/
static char * User_UART_Data_Find_Header(char * Buffer) 
{
	const char Header[] = {"{"};
	for(int i = 0;i < SIZE_OF_DATA_BUFFER;i++)
	{
		if(strncmp(&Buffer[i],Header,1) == 0)
		{
			return &Buffer[i];/*指向协议号头部*/
		}
	}
	return NULL;
}

static char * User_UART_Data_Find_Tail(char * Buffer)
{
	for(int i = 0;((i < SIZE_OF_DATA_BUFFER) && (Buffer[i] != NULL));i++)
	{
		if(Buffer[i] == '#')
		{
			Buffer[i] = '\0';
			return &Buffer[i] - 1;/*指向协议号尾部*/
		}
	}
	return NULL;
}









/*****************************END OF FILE***********************/
