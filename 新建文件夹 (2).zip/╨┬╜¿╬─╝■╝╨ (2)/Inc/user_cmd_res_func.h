#ifndef  __USER_CMD_RES_FUNC_H
#define  __USER_CMD_RES_FUNC_H

/* Includes ----------------------------------------------------------------------*/
#include "user_uart_data_analyze.h"
/* Exported types ----------------------------------------------------------------*/
/* Exported constants ------------------------------------------------------------*/
/* Exported macro ----------------------------------------------------------------*/
/*编译时间宏定义*/

#define __MONTH_IS_JAN (__DATE__[0] == 'J' && __DATE__[1] == 'a' && __DATE__[2] == 'n')
#define __MONTH_IS_FEB (__DATE__[0] == 'F')
#define __MONTH_IS_MAR (__DATE__[0] == 'M' && __DATE__[1] == 'a' && __DATE__[2] == 'r')
#define __MONTH_IS_APR (__DATE__[0] == 'A' && __DATE__[1] == 'p')
#define __MONTH_IS_MAY (__DATE__[0] == 'M' && __DATE__[1] == 'a' && __DATE__[2] == 'y')
#define __MONTH_IS_JUN (__DATE__[0] == 'J' && __DATE__[1] == 'u' && __DATE__[2] == 'n')
#define __MONTH_IS_JUL (__DATE__[0] == 'J' && __DATE__[1] == 'u' && __DATE__[2] == 'l')
#define __MONTH_IS_AUG (__DATE__[0] == 'A' && __DATE__[1] == 'u')
#define __MONTH_IS_SEP (__DATE__[0] == 'S')
#define __MONTH_IS_OCT (__DATE__[0] == 'O')
#define __MONTH_IS_NOV (__DATE__[0] == 'N')
#define __MONTH_IS_DEC (__DATE__[0] == 'D')

/*使用10进制打印，程序小了400K ！？*/
#ifdef __USE_CODE__

#define __GET_COMPILING_YEAR  ((uint32_t)(((__DATE__[9] - '0') << 4) | (__DATE__[10] - '0')))

#define __GET_COMPILING_MONTH   ((uint32_t)(__MONTH_IS_JAN ? 0x01 : (__MONTH_IS_FEB ? 0x02 : (__MONTH_IS_MAR ? 0x03 :\
                                           (__MONTH_IS_APR ? 0x04 : (__MONTH_IS_MAY ? 0x05 : (__MONTH_IS_JUN ? 0x06 :\
                                           (__MONTH_IS_JUL ? 0x07 : (__MONTH_IS_AUG ? 0x08 : (__MONTH_IS_SEP ? 0x09 :\
                                           (__MONTH_IS_OCT ? 0x10 : (__MONTH_IS_NOV ? 0x11 : (__MONTH_IS_DEC ? 0x12 : 0x0)))))))))))))
#define __GET_COMPILING_DAY     ((uint32_t)((__DATE__[4] == ' ')?(__DATE__[5] - '0'):(((__DATE__[4] - '0') << 4) | (__DATE__[5] - '0'))))

#define __GET_COMPILING_DATE    ((__GET_COMPILING_YEAR << 16) | (__GET_COMPILING_MONTH << 8) | __GET_COMPILING_DAY)

#endif /*__USE_CODE__*/

#define __GET_COMPILING_HOUR    ((uint32_t)(((__TIME__[0] - '0') << 4) | (__TIME__[1] - '0')))

#define __GET_COMPILING_MINUTE  ((uint32_t)(((__TIME__[3] - '0') << 4) | (__TIME__[4] - '0')))

#define __GET_COMPILING_SECOND  ((uint32_t)(((__TIME__[6] - '0') << 4) | (__TIME__[7] - '0')))  



#define __GET_COMPILING_TIME    ((__GET_COMPILING_HOUR << 16) | (__GET_COMPILING_MINUTE << 8) | __GET_COMPILING_SECOND)


#define __GET_COMPILING_YEAR_D  ((uint32_t)(((__DATE__[9] - '0') * 100000) + (__DATE__[10] - '0') * 10000))

#define __GET_COMPILING_MONTH_D (((uint32_t)(__MONTH_IS_JAN ? 1 : (__MONTH_IS_FEB ? 2 : (__MONTH_IS_MAR ? 3 :\
                                            (__MONTH_IS_APR ? 4 : (__MONTH_IS_MAY ? 5 : (__MONTH_IS_JUN ? 6 :\
                                            (__MONTH_IS_JUL ? 7 : (__MONTH_IS_AUG ? 8 : (__MONTH_IS_SEP ? 9 :\
                                            (__MONTH_IS_OCT ? 10 : (__MONTH_IS_NOV ? 11 : (__MONTH_IS_DEC ? 12 : 0))))))))))))) * 100)
#define __GET_COMPILING_DAY_D   ((uint32_t)((__DATE__[4] == ' ')?(__DATE__[5] - '0'):(((__DATE__[4] - '0') * 10) + (__DATE__[5] - '0'))))
#define __GET_COMPILING_DATE_D  ((__GET_COMPILING_YEAR_D ) + (__GET_COMPILING_MONTH_D ) + __GET_COMPILING_DAY_D)

/*软件编译日期*/
/* Exported functions ------------------------------------------------------------*/

#endif /*__USER_CMD_RES_FUNC_H*/
/*****************************END OF FILE***********************/
