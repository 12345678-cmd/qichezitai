#ifndef  __USER_GPIO_H
#define  __USER_GPIO_H

/* Includes -------------------------------------------------------------------*/
#include "main.h"
#include "user_timer.h"
/* Exported types -------------------------------------------------------------*/
/* Exported constants ---------------------------------------------------------*/
/* Exported macro -------------------------------------------------------------*/
/* Exported functions ---------------------------------------------------------*/
typedef struct
{
	GPIO_TypeDef* gpiox;
	uint16_t pin;
}gpio;



/*通用函数*/
void User_GPIO_Init(GPIO_TypeDef* GPIOX, uint16_t GPIO_PIN_X, int flag);
#endif /*__USER_GPIO_H*/
