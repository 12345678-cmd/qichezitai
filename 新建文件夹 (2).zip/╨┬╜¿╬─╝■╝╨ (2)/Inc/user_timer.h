#ifndef  __USER_TIMER_H
#define  __USER_TIMER_H

/* Includes -------------------------------------------------------------------*/
#include <stdint.h>
//#include <stdbool.h>

#include "main.h"
/* Exported types -------------------------------------------------------------*/
	
typedef enum
{
	TIMER_ID_UART_DATA_ANALYZE,            /*用于检查串口数据并解析的定时器*/
	TIMER_ID_SCAN_SENSOR,
	TIMER_ID_SEND_LOGIN_INFO,
	TIMER_ID_SEND_SENSOR_SCAN_RESULT,
	TIMER_ID_NUM,
}timer_ID_reg;


typedef struct
{
	uint32_t Current_Time;                 /*可以在循环开始统一得到各个定时器当前时间，逐一检查超时与否
											也可以判断的时候再当即获取，后者相对即时一点，
											且不用再主循环开始的时候去获取时间，目前没用到这个*/
	uint8_t  Timer_Status[TIMER_ID_NUM];   /*定时器开启或者关闭，开启才去检查是否*/
	uint32_t Start_Time[TIMER_ID_NUM];
	uint32_t Expire_Time[TIMER_ID_NUM];
}timer_man;/*定时器管理*/

/* Exported constants ---------------------------------------------------------*/
/* Exported macro -------------------------------------------------------------*/
#define TIMER_START  (uint8_t)1
#define TIMER_STOP   (uint8_t)0
/* Exported functions ---------------------------------------------------------*/
void User_Timer_Start(timer_ID_reg TimerID,uint32_t Expire_Time);

void User_TIM2_Init(void);
void User_TIM2_Power_Config(void);
void User_TIM2_IRQHandler(void);

uint8_t User_Timer_Start_Check(timer_ID_reg TimerID);
uint32_t User_Timer_Get_Expire_Time(timer_ID_reg TimerID);

void User_Timer_Stop(timer_ID_reg TimerID);
void User_Timer_Reflesh(timer_ID_reg TimerID);

uint32_t User_Timer_Elapsed_Time(timer_ID_reg TimerID);
uint8_t User_Timer_Expire_Check(timer_ID_reg TimerID);
uint8_t User_Timer_Start_Expire_Check(timer_ID_reg TimerID);
#endif /*__USER_TIMER_H*/
/*****************************END OF FILE***********************/
