#ifndef  __USER_UART_H
#define  __USER_UART_H

/* Includes -------------------------------------------------------------------*/
#include "main.h"
#include "user_timer.h"
/* Exported types -------------------------------------------------------------*/
typedef enum
{
	UART_STATE_RX_READY,
	UART_STATE_RX_BUSY,
	UART_STATE_RX_COPY,
	UART_STATE_RX_NEW_ROUND,
	UART_STATE_RX_STOP
}UART_STATE_RX;

/* Exported constants ---------------------------------------------------------*/
/* Exported macro -------------------------------------------------------------*/
/*需要用到MicroLIB*/
#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
/* Exported functions ---------------------------------------------------------*/
/*通用函数，最重要的功能之一，单片机的大量信息通过此发出
被外界调用函数,屏蔽功能后对外什么也不做
*/
void User_UART_Init(void);
void User_UART_Data_Analyze_Respond(void);
void User_UART_IRQHandler(void);
/*平台变化变代码*/
void User_UART_Power_Config(void);


#endif /*__USER_UART_H*/


/*****************************END OF FILE***********************/
