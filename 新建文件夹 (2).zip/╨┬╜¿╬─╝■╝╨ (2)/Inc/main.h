/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes -------------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
/*通用的部分可以放到宏外面*/

#include "stm32f4xx_hal.h"

/* Exported types -------------------------------------------------------------*/

#define USER_IWDG_DEFAULT_TIMEOUT   39U

//MCU与GSM通讯串口
#define GPIO_PIN_MCU_UTX             GPIO_PIN_8
#define GPIO_PIN_MCU_URX             GPIO_PIN_9
#define GPIO_PORT_MCU_UTX_URX        GPIOD

#define USARTx_RX_GPIO_CLK_ENABLE()  __HAL_RCC_GPIOD_CLK_ENABLE()
#define USARTx_TX_GPIO_CLK_ENABLE()  __HAL_RCC_GPIOD_CLK_ENABLE()


/*这是RCC模块控制的*/
/*平台相关性，打开项目宏，打开另一个平台的平台宏，运行是怎样的，宏的名字要相同才有意义*/
/*两个平台可使用相同的GPIO实现UART*/
#define USARTx                      USART3
#define USARTx_CLK_ENABLE()         __HAL_RCC_USART3_CLK_ENABLE()
#define USARTx_CLK_DISABLE()        __HAL_RCC_USART3_CLK_DISABLE()
#define USARTx_FORCE_RESET()        __HAL_RCC_USART3_FORCE_RESET()
#define USARTx_RELEASE_RESET()      __HAL_RCC_USART3_RELEASE_RESET()

/* Definition for USARTx Pins */
#define USARTx_TX_PIN                    GPIO_PIN_8
#define USARTx_TX_GPIO_PORT              GPIOD
#define USARTx_TX_AF                     GPIO_AF7_USART3
#define USARTx_RX_PIN                    GPIO_PIN_9
#define USARTx_RX_GPIO_PORT              GPIOD
#define USARTx_RX_AF                     GPIO_AF7_USART3

/*GPIO引脚的特殊功能定义*/
#define USARTx_TX_AF                GPIO_AF7_USART3
#define USARTx_RX_AF                GPIO_AF7_USART3

/*与型号密切相关的，和寄存器定义等在CMSIS\STM32F0xx\Include\stm32f031x6.h*/
/* Definition for USARTx's NVIC */
#define USARTx_IRQn                 USART3_IRQn
#define USARTx_IRQHandler           USART3_IRQHandler

#define  BAUDRATE                   9600

/* Exported macro ------------------------------------------------------------*/
#define COUNTOF(__BUFFER__)        (sizeof(__BUFFER__) / sizeof(*(__BUFFER__)))
#define SIZE_OF(__BUFFER__)        (COUNTOF(__BUFFER__))
#define SIZE_OF_DATA_BUFFER        1200
/*一个作为清空标志*/
#define SIZE_OF_FULL_BUFFER        1200 + 2

#define RTC_CLOCK_SOURCE_LSI
#define RTC_ASYNCH_PREDIV               0x7F
#define RTC_SYNCH_PREDIV                0x0137


/*增强可读性*/

#define TIM2_UPDATE_TIME             10 /*10ms*/

/* Definition for TIMx clock resources */
#define TIMx                         TIM2
#define TIMx_CLK_ENABLE()            __HAL_RCC_TIM2_CLK_ENABLE()
#define TIMx_CLK_DISABLE()           __HAL_RCC_TIM2_CLK_DISABLE()

/* Definition for TIMx's NVIC */
#define TIMx_IRQn                    TIM2_IRQn
#define TIMx_IRQHandler              TIM2_IRQHandler
/* Exported functions --------------------------------------------------------*/

typedef enum loginstatus
{
	LOGOUT,
	LOGIN,
	WAITFOR_RESPOND
}loginstatus;		
typedef enum switch_status
{
	SWITCH_OFF,
	SWITCH_ON
}switch_status;
typedef struct protocal_send_switch
{
	switch_status login_info_switch;
	switch_status sensor_scan_result_switch;
}protocal_send_switch;
#endif /* __MAIN_H */
/*****************************END OF FILE***********************/
