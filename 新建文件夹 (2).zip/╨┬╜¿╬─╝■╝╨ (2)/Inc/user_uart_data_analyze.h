#ifndef  __UART_DATA_ANALYZE_H
#define  __UART_DATA_ANALYZE_H

/* Includes -------------------------------------------------------------------*/
#include "main.h"
#include "cJSON.h"
/* Exported macro -------------------------------------------------------------*/


/* Exported types -------------------------------------------------------------*/

typedef struct
{
	char     *Header;      /*指令头*/
    char     *Tail;        /*本条指令尾部，可以能有多条指令并收的情况*/
	uint32_t JsonID;       /*id字段*/
	uint32_t JsonDir;      /*direction字段*/
	char     *JsonType; /*type字段*/
	cJSON    *JsonBody;    /*body字段*/
	uint32_t JsonCrc;      /*crc字段*/
}command_para;
/* Exported constants ---------------------------------------------------------*/

/* Exported functions ---------------------------------------------------------*/

/**/
void User_UART_Data_Analyze_String( char * Buffer ,command_para * Command_Param);
uint8_t ParseScanCodeJson(const char* pszJsonText);
#endif /*__UART_DATA_ANALYZE_H*/
/*****************************END OF FILE***********************/
